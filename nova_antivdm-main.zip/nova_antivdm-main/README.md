# Nova Anti-VDM Your Vehicular Justice Solution!

Sick of unfair VDM on your FiveM server? Nova Anti-VDM is here. Stop reckless vehicle hits, promote fairness, elevate gameplay. Get it now, say no to VDM, yes to better gaming.


[Support](https://discord.gg/HNhCsR9cHU)

[Video Preview](https://youtu.be/VD2JJ1KqFSQ)

[Cfx Forums](https://forum.cfx.re/t/free-standalone-nova-anti-vdm/5159555)


## **Dependencies**
- screenshot-basic (only for logs)
- ox_lib (only for notifications)

## **Features**
- Trigger protection
- Anti Vdm
- Discord logs
- Internal kick system
- Auto heal on vdm
- Easy Config
- Otimized (0.0ms in use)

## **Installation**
1. Download / Close the resource
2. Insert the resource in your /resources folder
3. Rename the resource to nova_antivdm
4. Change the config to your likings
5. `ensure nova_antivdm` in your `server.cfg`
6. Restart the server 
